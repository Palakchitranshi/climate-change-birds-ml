import pandas as pd
import matplotlib.pyplot as plt

# Load CSV data
data = pd.read_csv('bird_data.csv')

# Print a summary
print("Bird Data Summary:\n", data.describe())

# Plot temperature vs food availability (dummy logic)
plt.figure(figsize=(10, 5))
plt.title("Bird Migration vs Temperature")
plt.scatter(data['temperature'], data['food_availability'].apply(lambda x: {'Low':1, 'Medium':2, 'High':3}[x]), color='green')
plt.xlabel("Temperature (°C)")
plt.ylabel("Food Availability (1=Low, 3=High)")
plt.grid(True)
plt.show()
