# Effects of Climate Change on Birds

This project analyzes how climate change impacts bird species, particularly their migration, reproduction, and survival. It uses Python for data analysis and visualization, and MySQL for data storage.

## 🔍 Objectives
- Analyze temperature shifts and their impact on food availability.
- Visualize migration patterns.
- Predict bird population risks using modeling.

## 🧪 Technologies Used
- Python (pandas, matplotlib)
- MySQL
- CSV data handling
- Data modeling and simulation

## 📂 File Structure
- `bird_data.csv` — Sample migration data
- `climate_model.py` — Analysis and visualization
- `database_config.py` — MySQL connection config
- `requirements.txt` — Libraries to install

## 📊 Output
- Visuals of bird behavior under changing climate
- Data summary and potential conservation insights

## 🧑‍💻 Contributors
- Palak Chitranshi (13501012023)
- Niharika Verma (12901012023)
- Karan Chandna (2301730131)
