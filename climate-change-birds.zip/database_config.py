import mysql.connector

# Connect to MySQL (update with your local details)
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",
    database="bird_climate_db"
)

cursor = conn.cursor()
cursor.execute("SHOW TABLES")
for table in cursor:
    print(table)
conn.close()
